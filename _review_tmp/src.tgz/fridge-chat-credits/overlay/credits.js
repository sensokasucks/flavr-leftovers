(() => {
  const PLATFORM_ORDER = ["twitch", "kick", "youtube", "manual"];
  const PLATFORM_LABEL = { twitch: "Twitch", kick: "Kick", youtube: "YouTube", manual: "Chat" };
  const PAGE_MOTIONS = new Set(["cards", "fade", "slides", "typewriter"]);
  const CRAWL_MOTIONS = new Set(["crawl", "crawl-down", "starwars"]);

  const qs = new URLSearchParams(location.search);
  let theme = {};
  let roster = { chatters: [], count: 0 };
  let play = { playing: true, mode: "loop", freeze: false, generation: 0 };
  let rebuildTimer = 0;
  let lastRosterKey = "";
  let lastThemeKey = "";
  let io = null;
  let pageTimer = 0;
  let typeTimer = 0;

  const crawl = {
    raf: 0,
    y: 0,
    x: 0,
    startY: 0,
    endY: 0,
    lastTs: 0,
    running: false,
    gapUntil: 0,
    generation: -1,
    started: false,
    linear: 0,
    travel: 1,
    fading: false,
  };

  const pages = {
    index: 0,
    items: [],
    running: false,
  };

  function num(v, fallback) {
    const n = Number(v);
    return Number.isFinite(n) ? n : fallback;
  }

  function bool(v, fallback) {
    if (v === true || v === false) return v;
    if (v === "true") return true;
    if (v === "false") return false;
    return fallback;
  }

  function ease(t, kind) {
    const x = Math.max(0, Math.min(1, t));
    if (kind === "ease-in") return x * x;
    if (kind === "ease-out") return 1 - (1 - x) * (1 - x);
    if (kind === "ease-in-out") return x < 0.5 ? 2 * x * x : 1 - Math.pow(-2 * x + 2, 2) / 2;
    if (kind === "smooth") return x * x * (3 - 2 * x);
    return x;
  }

  function applyQuery(t) {
    const out = { ...t };
    for (const [k, v] of qs.entries()) {
      if (k === "demo") continue;
      if (v === "true") out[k] = true;
      else if (v === "false") out[k] = false;
      else if (v !== "" && !Number.isNaN(Number(v)) && String(Number(v)) === v) out[k] = Number(v);
      else out[k] = v;
    }
    return out;
  }

  function shadowFrom(t) {
    if (t.text_shadow && t.shadow_strength == null) return t.text_shadow;
    const s = num(t.shadow_strength, 8);
    if (s <= 0) return "none";
    return `0 2px ${s}px rgba(0,0,0,0.85)`;
  }

  function applyTheme(t) {
    theme = applyQuery(t || {});
    const r = document.documentElement.style;
    r.setProperty("--title-color", theme.title_color || "#f3e2b0");
    r.setProperty("--name-color", theme.name_color || "#f4f0e6");
    r.setProperty("--muted", theme.muted_color || "#9a8f78");
    r.setProperty("--mod", theme.mod_color || "#e8c36a");
    r.setProperty("--vip", theme.vip_color || "#c9a0ff");
    r.setProperty("--font", theme.font_family || "Georgia, serif");
    r.setProperty("--title-size", (theme.title_size_px || 54) + "px");
    r.setProperty("--name-size", (theme.name_size_px || 22) + "px");
    r.setProperty("--subtitle-size", (theme.subtitle_size_px || 26) + "px");
    r.setProperty("--footer-size", (theme.footer_size_px || 28) + "px");
    r.setProperty("--title-weight", String(theme.title_weight || 600));
    r.setProperty("--name-weight", String(theme.name_weight || 500));
    r.setProperty("--shadow", shadowFrom(theme));
    r.setProperty("--track", (theme.letter_spacing_em || 0.04) + "em");
    r.setProperty("--col-gap", (theme.column_gap_px || 48) + "px");
    r.setProperty("--row-gap", (theme.row_gap_px || 10) + "px");
    r.setProperty("--max-w", (theme.max_width_px || 920) + "px");
    r.setProperty("--mask", Math.max(0, num(theme.mask_fade_px, 72)) + "px");
    r.setProperty("--perspective", (theme.perspective_px || 420) + "px");
    r.setProperty("--tilt", (theme.tilt_deg || 52) + "deg");
    r.setProperty("--title-case", bool(theme.uppercase_title, true) ? "uppercase" : "none");
    r.setProperty("--name-case", bool(theme.uppercase_names, false) ? "uppercase" : "none");
    r.setProperty("--align", theme.align === "left" ? "left" : "center");
    r.setProperty("--stage-opacity", String(num(theme.opacity, 1)));
    r.setProperty("--page-ms", Math.max(120, num(theme.page_transition_ms, 700)) + "ms");
    const glowOn = bool(theme.glow, false);
    const glowPx = num(theme.glow_px, 16);
    r.setProperty("--glow", glowOn ? `0 0 ${glowPx}px ${theme.glow_color || "#e8c36a"}` : "0 0 0 transparent");

    const bg = theme.background || "transparent";
    document.body.style.background = bg;
    document.body.classList.toggle("solid", bg !== "transparent");
    if (bg !== "transparent") {
      r.setProperty("--fade-from", bg);
    }

    const stage = document.getElementById("stage");
    const motion = theme.motion || "crawl";
    stage.className = "";
    stage.classList.toggle("solid-stage", bg !== "transparent");
    stage.classList.toggle("has-vignette", bool(theme.vignette, false));
    stage.classList.toggle("no-mask", num(theme.mask_fade_px, 72) <= 0);
    stage.classList.toggle(
      "soft-mask",
      bg === "transparent" && num(theme.mask_fade_px, 72) > 0
    );
    stage.classList.toggle("align-left", theme.align === "left");
    if (PAGE_MOTIONS.has(motion)) stage.classList.add("motion-pages");
    if (motion === "starwars") stage.classList.add("motion-starwars");
    if (motion === "ticker") stage.classList.add("motion-ticker");
    if (motion === "cards") stage.classList.add("trans-cards");
    else if (motion === "slides") stage.classList.add("trans-slides");
    else if (PAGE_MOTIONS.has(motion)) stage.classList.add("trans-fade");

    if (theme.custom_font_url) {
      let link = document.getElementById("custom-font");
      if (!link) {
        link = document.createElement("link");
        link.id = "custom-font";
        link.rel = "stylesheet";
        document.head.appendChild(link);
      }
      if (link.href !== theme.custom_font_url) link.href = theme.custom_font_url;
    }
  }

  function esc(s) {
    return String(s || "")
      .replace(/&/g, "\u0026amp;")
      .replace(/</g, "\u0026lt;")
      .replace(/>/g, "\u0026gt;")
      .replace(/"/g, "\u0026quot;");
  }

  function letterize(text) {
    const chars = Array.from(String(text || ""));
    return chars
      .map((ch, i) => {
        const safe = ch === " " ? "&nbsp;" : esc(ch);
        return `<span class="ch" style="animation-delay:${i * 38}ms">${safe}</span>`;
      })
      .join("");
  }

  function nameCell(c) {
    const showPlat = theme.show_platform !== false;
    const showCount = !!theme.show_message_count;
    const hl = theme.highlight_mods !== false && c.is_mod;
    const vip = bool(theme.highlight_vips, false) && c.is_vip && !hl;
    const enter = enterClass();
    const dot = showPlat ? `<span class="dot ${esc(c.platform)}"></span>` : "";
    const count = showCount ? `<span class="count">${c.messages || 1}</span>` : "";
    const klass = `name${hl ? " mod" : ""}${vip ? " vip" : ""}${enter}`;
    return `<div class="${klass}">${dot}${esc(c.display_name || c.username)}${count}</div>`;
  }

  function enterClass() {
    const kind = theme.name_enter || "none";
    if (!kind || kind === "none") return "";
    return ` enter-${kind}`;
  }

  function grid(list, cols) {
    return `<div class="grid cols-${cols}" style="--cols:${cols}">${list.map(nameCell).join("")}</div>`;
  }

  function rosterKey(r) {
    const jobs = (r.chatters || []).map((c) => c.job || "").join(",");
    return (r.style || "") + "~" + jobs + "~" + (r.chatters || []).map((c) => c.platform + ":" + c.username).join("|");
  }

  function themeKey(t) {
    return JSON.stringify(t || {});
  }

  function jobRow(row) {
    const hl = theme.highlight_mods !== false && row.is_mod;
    const vip = bool(theme.highlight_vips, false) && row.is_vip && !hl;
    const layout = theme.job_layout || "dots";
    const extra = layout !== "dots" ? ` ${layout}` : "";
    const enter = enterClass();
    return `<div class="job-row${extra}${enter}">
      <div class="job">${esc(row.job || "")}</div>
      <div class="dots"></div>
      <div class="who${hl ? " mod" : ""}${vip ? " vip" : ""}">${esc(row.display_name || row.username)}</div>
    </div>`;
  }

  function personKey(c) {
    return String(c.display_name || c.username || "").trim().toLowerCase();
  }

  function renderMovieBlocks(cast, cols) {
    if (!cast) return [];
    const seen = new Set();
    const take = (list) => {
      const out = [];
      for (const c of list || []) {
        const k = personKey(c);
        if (!k || seen.has(k)) continue;
        seen.add(k);
        out.push(c);
      }
      return out;
    };
    const blocks = [];
    for (const d of cast.departments || []) {
      const rows = take(d.rows || []);
      if (!rows.length) continue;
      blocks.push({
        title: d.title,
        html: `<div class="section">${esc(d.title)}</div>${rows.map(jobRow).join("")}`,
      });
    }
    for (const g of cast.groups || []) {
      const members = take(g.chatters || []);
      if (!members.length) continue;
      blocks.push({
        title: g.title || g.id,
        html: `<div class="section">${esc(g.title || g.id)}</div>${grid(members, cols)}`,
      });
    }
    const extra = take((cast.overflow && cast.overflow.chatters) || []);
    if (extra.length) {
      const title = (cast.overflow && cast.overflow.title) || "Additional Voices";
      blocks.push({
        title,
        html: `<div class="section">${esc(title)}</div>${grid(extra, cols)}`,
      });
    }
    return blocks;
  }

  function renderNameBlocks(cols) {
    const label = theme.section_label || "Chatters";
    const group = !!theme.group_by_platform;
    const chatters = roster.chatters || [];
    if (!chatters.length) return [];
    if (group) {
      const buckets = {};
      for (const c of chatters) {
        (buckets[c.platform] || (buckets[c.platform] = [])).push(c);
      }
      const keys = [
        ...PLATFORM_ORDER.filter((p) => buckets[p]?.length),
        ...Object.keys(buckets).filter((p) => !PLATFORM_ORDER.includes(p)),
      ];
      return keys.map((p) => ({
        title: PLATFORM_LABEL[p] || p,
        html: `<div class="plat-block">
            <div class="plat-h ${esc(p)}">${esc(PLATFORM_LABEL[p] || p)}</div>
            ${grid(buckets[p], cols)}
          </div>`,
      }));
    }
    return [{ title: label, html: `<div class="section">${esc(label)}</div>${grid(chatters, cols)}` }];
  }

  function titleHtml() {
    const title = theme.title || "Thanks for watching";
    const intro = theme.title_intro || "none";
    const inner = intro === "letters" ? letterize(title) : esc(title);
    const introClass = intro && intro !== "none" ? ` intro-${intro === "letters" ? "fade" : intro}` : "";
    const subtitle = theme.subtitle || "";
    const rule = theme.rule_style || "gradient";
    return `
      <div class="title${introClass}">${inner}</div>
      ${subtitle ? `<div class="subtitle">${esc(subtitle)}</div>` : ""}
      <div class="rule ${esc(rule)}"></div>
    `;
  }

  function footerHtml() {
    const footer = theme.footer || "";
    return footer ? `<div class="footer">${esc(footer)}</div>` : "";
  }

  function tickerNames() {
    const chatters = roster.chatters || [];
    if (!chatters.length) return `<div class="empty">Waiting for chat</div>`;
    const cells = chatters.map(nameCell).join("");
    return `<div class="ticker"><div class="ticker-track" id="ticker-track">${cells}${cells}</div></div>`;
  }

  function renderNames() {
    const reel = document.getElementById("reel");
    const cols = Math.max(1, Math.min(4, num(theme.columns, 2)));
    const movie = (roster.style || theme.style) === "movie" && roster.cast;
    const motion = theme.motion || "crawl";
    const chatters = roster.chatters || [];

    const blocks = movie ? renderMovieBlocks(roster.cast, cols) : renderNameBlocks(cols);
    const bodyBlocks = chatters.length ? blocks : [{ title: "empty", html: `<div class="empty">Waiting for chat</div>` }];

    if (PAGE_MOTIONS.has(motion)) {
      const pagesHtml = [];
      pagesHtml.push(`<div class="page${motion === "typewriter" ? " typewriter" : ""}" data-page="title">${titleHtml()}</div>`);
      bodyBlocks.forEach((b, i) => {
        pagesHtml.push(
          `<div class="page${motion === "typewriter" ? " typewriter" : ""}" data-page="b${i}">${b.html}</div>`
        );
      });
      if (theme.footer) {
        pagesHtml.push(`<div class="page" data-page="footer">${footerHtml()}</div>`);
      }
      reel.innerHTML = pagesHtml.join("");
      return;
    }

    if (motion === "ticker") {
      reel.innerHTML = `${titleHtml()}${tickerNames()}${footerHtml()}`;
      return;
    }

    reel.innerHTML = `
      ${titleHtml()}
      ${bodyBlocks.map((b) => b.html).join("")}
      ${footerHtml()}
    `;
  }

  function bindEnterObserver() {
    if (io) {
      io.disconnect();
      io = null;
    }
    const kind = theme.name_enter || "none";
    if (!kind || kind === "none") return;
    if (!CRAWL_MOTIONS.has(theme.motion || "crawl") && (theme.motion || "crawl") !== "ticker") return;
    const stage = document.getElementById("stage");
    const nodes = document.querySelectorAll(".enter-fade, .enter-rise, .enter-slide, .enter-blur");
    if (!nodes.length) return;
    const stagger = Math.max(0, num(theme.name_stagger_ms, 40));
    io = new IntersectionObserver(
      (entries) => {
        for (const e of entries) {
          if (!e.isIntersecting) continue;
          const delay = Number(e.target.dataset.stagger || 0);
          setTimeout(() => e.target.classList.add("in"), delay);
          io.unobserve(e.target);
        }
      },
      { root: stage, threshold: 0.12 }
    );
    nodes.forEach((n, i) => {
      n.dataset.stagger = String((i % 12) * stagger);
      io.observe(n);
    });
  }

  function metrics() {
    const stage = document.getElementById("stage");
    const reel = document.getElementById("reel");
    const stageH = stage.clientHeight || window.innerHeight || 720;
    const height = reel.scrollHeight || 0;
    const down = (theme.motion || "crawl") === "crawl-down";
    return {
      stageH,
      height,
      startY: down ? -height : stageH,
      endY: down ? stageH : -height,
      down,
    };
  }

  function tilt() {
    return (theme.motion || "crawl") === "starwars" ? ` rotateX(${num(theme.tilt_deg, 52)}deg)` : "";
  }

  function applyY(y) {
    const reel = document.getElementById("reel");
    reel.style.transform = `translate3d(-50%, ${y}px, 0)${tilt()}`;
  }

  function holdY() {
    const m = metrics();
    if (m.height <= m.stageH * 0.92) {
      return Math.max(24, (m.stageH - m.height) / 2);
    }
    return 48;
  }

  function syncMetrics() {
    const m = metrics();
    crawl.startY = m.startY;
    crawl.endY = m.endY;
    crawl.travel = Math.max(1, Math.abs(m.startY - m.endY));
  }

  function stopRaf() {
    crawl.running = false;
    crawl.lastTs = 0;
    if (crawl.raf) {
      cancelAnimationFrame(crawl.raf);
      crawl.raf = 0;
    }
  }

  function clearTimers() {
    if (pageTimer) {
      clearTimeout(pageTimer);
      pageTimer = 0;
    }
    if (typeTimer) {
      clearTimeout(typeTimer);
      typeTimer = 0;
    }
    pages.running = false;
  }

  function resetToStart() {
    syncMetrics();
    crawl.linear = 0;
    crawl.y = crawl.startY;
    crawl.x = 0;
    crawl.gapUntil = 0;
    crawl.lastTs = 0;
    crawl.fading = false;
    const reel = document.getElementById("reel");
    reel.classList.remove("out", "loop-fade", "loop-wipe");
    reel.style.opacity = "";
    applyY(crawl.y);
  }

  function crawlSpeed(travel) {
    const target = num(theme.duration_sec, 0);
    if (target > 0) return Math.max(4, travel / target);
    return Math.max(8, num(theme.speed_px_per_sec, 42));
  }

  function afterLoop(ts, restartFn) {
    const mode = play.mode || theme.mode || "loop";
    if (mode === "once") {
      play.mode = "hold";
      stopRaf();
      return;
    }
    const trans = theme.loop_transition || "cut";
    const gap = Math.max(0, num(theme.gap_after_loop_sec, 2.5));
    const reel = document.getElementById("reel");
    const finish = () => {
      restartFn();
      crawl.lastTs = 0;
      if (gap > 0) crawl.gapUntil = performance.now() + gap * 1000;
      crawl.fading = false;
    };
    if (trans === "fade" || trans === "wipe") {
      crawl.fading = true;
      reel.classList.add(trans === "wipe" ? "loop-wipe" : "loop-fade", "out");
      setTimeout(finish, trans === "wipe" ? 520 : 460);
    } else {
      finish();
    }
  }

  function tickCrawl(ts) {
    if (!crawl.running) return;
    crawl.raf = requestAnimationFrame(tickCrawl);

    const mode = play.mode || theme.mode || "loop";
    if (play.playing === false || mode === "hold") return;
    if (crawl.fading) return;
    if (crawl.gapUntil && ts < crawl.gapUntil) return;
    crawl.gapUntil = 0;

    if (!crawl.lastTs) crawl.lastTs = ts;
    const dt = Math.min(0.05, (ts - crawl.lastTs) / 1000);
    crawl.lastTs = ts;

    syncMetrics();
    const speed = crawlSpeed(crawl.travel);
    crawl.linear += (speed * dt) / crawl.travel;
    if (crawl.linear >= 1) {
      crawl.linear = 1;
      crawl.y = crawl.endY;
      applyY(crawl.y);
      afterLoop(ts, () => {
        crawl.linear = 0;
        crawl.y = crawl.startY;
        const reel = document.getElementById("reel");
        reel.classList.remove("out");
        applyY(crawl.y);
      });
      return;
    }
    const p = ease(crawl.linear, theme.easing || "linear");
    const down = (theme.motion || "crawl") === "crawl-down";
    crawl.y = down
      ? crawl.startY + (crawl.endY - crawl.startY) * p
      : crawl.startY - crawl.travel * p;
    applyY(crawl.y);
  }

  function tickTicker(ts) {
    if (!crawl.running) return;
    crawl.raf = requestAnimationFrame(tickTicker);
    const mode = play.mode || theme.mode || "loop";
    if (play.playing === false || mode === "hold") return;
    if (crawl.gapUntil && ts < crawl.gapUntil) return;
    crawl.gapUntil = 0;
    if (!crawl.lastTs) crawl.lastTs = ts;
    const dt = Math.min(0.05, (ts - crawl.lastTs) / 1000);
    crawl.lastTs = ts;
    const track = document.getElementById("ticker-track");
    if (!track) return;
    const speed = Math.max(20, num(theme.speed_px_per_sec, 42) * 1.4);
    crawl.x -= speed * dt;
    const half = track.scrollWidth / 2;
    if (half > 0 && Math.abs(crawl.x) >= half) {
      crawl.x += half;
      const once = (play.mode || theme.mode) === "once";
      if (once) {
        play.mode = "hold";
        stopRaf();
        return;
      }
    }
    track.style.transform = `translate3d(${crawl.x}px, 0, 0)`;
  }

  function showPage(i, exiting) {
    const items = pages.items;
    items.forEach((el, idx) => {
      el.classList.toggle("active", idx === i);
      el.classList.toggle("exit", idx === exiting);
    });
    pages.index = i;
  }

  function typePageThen(el, done) {
    const nodes = [...el.querySelectorAll(".name, .job-row")];
    if (!nodes.length) {
      done();
      return;
    }
    nodes.forEach((n) => n.classList.remove("typed"));
    let i = 0;
    const delay = Math.max(20, num(theme.type_ms, 55));
    const step = () => {
      if (!pages.running) return;
      if (i >= nodes.length) {
        done();
        return;
      }
      nodes[i++].classList.add("typed");
      typeTimer = setTimeout(step, delay);
    };
    step();
  }

  function runPages() {
    clearTimers();
    pages.items = [...document.querySelectorAll("#reel .page")];
    pages.index = 0;
    pages.running = true;
    if (!pages.items.length) return;

    const hold = Math.max(0.8, num(theme.page_duration_sec, 4.5)) * 1000;
    const trans = Math.max(120, num(theme.page_transition_ms, 700));

    const advance = () => {
      if (!pages.running) return;
      const mode = play.mode || theme.mode || "loop";
      if (play.playing === false || mode === "hold") return;
      const next = pages.index + 1;
      if (next >= pages.items.length) {
        if (mode === "once") {
          play.mode = "hold";
          pages.running = false;
          return;
        }
        const gap = Math.max(0, num(theme.gap_after_loop_sec, 2.5)) * 1000;
        pageTimer = setTimeout(() => {
          showPage(0, pages.items.length - 1);
          playPage();
        }, gap);
        return;
      }
      showPage(next, pages.index);
      playPage();
    };

    const playPage = () => {
      const el = pages.items[pages.index];
      if (!el) return;
      if ((theme.motion || "") === "typewriter") {
        typePageThen(el, () => {
          pageTimer = setTimeout(advance, hold);
        });
      } else {
        pageTimer = setTimeout(advance, hold + trans * 0.25);
      }
    };

    showPage(0, -1);
    const titleHold = Math.max(0, num(theme.title_hold_sec, 0)) * 1000;
    pageTimer = setTimeout(playPage, titleHold);
  }

  function startOrResumeCrawl(opts) {
    const motion = theme.motion || "crawl";
    const mode = play.mode || theme.mode || "loop";
    stopRaf();
    clearTimers();

    if (play.playing === false || mode === "hold") {
      if (PAGE_MOTIONS.has(motion)) {
        pages.items = [...document.querySelectorAll("#reel .page")];
        if (pages.items.length) showPage(0, -1);
        return;
      }
      if (motion === "ticker") return;
      crawl.y = holdY();
      applyY(crawl.y);
      crawl.started = true;
      return;
    }

    if (PAGE_MOTIONS.has(motion)) {
      runPages();
      crawl.started = true;
      return;
    }

    if (motion === "ticker") {
      crawl.x = 0;
      const track = document.getElementById("ticker-track");
      if (track) track.style.transform = "translate3d(0,0,0)";
      crawl.started = true;
      crawl.running = true;
      crawl.lastTs = 0;
      crawl.raf = requestAnimationFrame(tickTicker);
      return;
    }

    syncMetrics();
    if ((opts && opts.reset) || !crawl.started) {
      resetToStart();
      crawl.started = true;
      const hold = Math.max(0, num(theme.title_hold_sec, 0));
      if (hold > 0) crawl.gapUntil = performance.now() + hold * 1000;
    } else {
      if (crawl.linear < 0) crawl.linear = 0;
      if (crawl.linear > 1) crawl.linear = 0;
      applyY(crawl.y);
    }

    if (!crawl.running) {
      crawl.running = true;
      crawl.lastTs = 0;
      crawl.raf = requestAnimationFrame(tickCrawl);
    }
  }

  function paint(opts) {
    const rk = rosterKey(roster);
    const tk = themeKey(theme);
    const namesChanged = rk !== lastRosterKey || tk !== lastThemeKey;
    if (namesChanged || !crawl.started) {
      renderNames();
      lastRosterKey = rk;
      lastThemeKey = tk;
      bindEnterObserver();
    }

    const gen = Number(play.generation || 0);
    const reset = !!(opts && opts.reset) || gen !== crawl.generation || namesChanged;
    crawl.generation = gen;
    startOrResumeCrawl({ reset });
  }

  function schedulePaint(opts) {
    clearTimeout(rebuildTimer);
    rebuildTimer = setTimeout(() => paint(opts || {}), 40);
  }

  async function boot() {
    try {
      const [t, r, p] = await Promise.all([
        fetch("/api/credits/theme").then((x) => x.json()),
        fetch("/api/credits/roster").then((x) => x.json()),
        fetch("/api/credits/play").then((x) => x.json()),
      ]);
      applyTheme(t);
      roster = r;
      play = p;
    } catch (e) {
      applyTheme({});
    }
    paint({ reset: true });
    connectWs();
  }

  function connectWs() {
    const proto = location.protocol === "https:" ? "wss" : "ws";
    const ws = new WebSocket(`${proto}://${location.host}/ws`);
    ws.onmessage = (ev) => {
      let msg;
      try {
        msg = JSON.parse(ev.data);
      } catch {
        return;
      }
      const kind = msg.type || "";
      if (kind === "theme" || kind === "credits_theme") {
        applyTheme(msg.data);
        schedulePaint({ reset: true });
      }
      if (kind === "roster" || kind === "credits_roster") {
        roster = msg.data;
        schedulePaint();
      }
      if (kind === "play" || kind === "credits_play") {
        play = msg.data;
        schedulePaint();
      }
    };
    ws.onclose = () => setTimeout(connectWs, 2000);
  }

  window.addEventListener("resize", () => {
    if (PAGE_MOTIONS.has(theme.motion || "crawl") || (theme.motion || "") === "ticker") return;
    syncMetrics();
    if (play.mode === "hold" || play.playing === false) {
      crawl.y = holdY();
      applyY(crawl.y);
    }
  });

  boot();
})();
