# Checklist — Credits (built into Stream Core)

Home: `core/credits.py`, `core/cast.py`, `core/credits_theme.py`, `overlay/credits.*`, Admin Credits tab. Spec: `overlay/CREDITS.md`.

Standalone twin: [chat-credits-standalone.md](chat-credits-standalone.md) — same cast module idea, different process.

## Must keep

- [ ] Opt-in: `credits.enabled` default **false**. Enable from Admin → Credits (hot-applied) or Config checkbox.
- [ ] Unique chatters come from the **same** Kick / Twitch / YouTube adapters as live chat. No second listener.
- [ ] Overlay URL: `http://127.0.0.1:3850/overlay/credits.html` (transparent Webpage source).
- [ ] Crawl uses pixel `requestAnimationFrame` + `credits.speed_px_per_sec`. Do **not** go back to CSS `@keyframes` + `translateY(%)` (CEF dropped that animation).
- [ ] Modes: `loop` / `once` / `hold`. Roll credits freezes the unique list and restarts the crawl from below the frame. Live appends do not jump to the top.
- [ ] Cast styles in `config/cast/*.json` (`names` or `movie`). Shipped style: `movie.json`.
- [ ] Persistent job pins in `data/cast_overrides.json` survive session reset and roll.
- [ ] Groups: mods, subs, starring (top talkers); raiders / followers / gifted-subs from the alert bus.
- [ ] Commands (group `credits`, bind `credits`):
  - `!credit "name" "job title"` (aliases `!job`, `!cast`)
  - `!credit "name" clear`
  - `!credits` (unique chatter count)
- [ ] `credits.command_permission`: `mod` (default) / `admin` / `public`.
- [ ] Job titles capped at **50** characters.
- [ ] Session list saved to `data/credits_session.json`.
- [ ] Admin → Credits API must include `cast` (styles, current style, pins, `command_permission`, job cap) **and** write routes:
  - `PUT /credits/cast/style`
  - `PUT /credits/cast/file`
  - `POST /credits/cast/pin`
  - `PUT /credits/command-permission`
- [ ] Style editor: Motion / Copy / Type / Color / Layout / List + live preview + look presets (Classic, Star Wars, Gold, Neon, Teletype, End card, Name tape, Minimal).
- [ ] Motions: `crawl`, `crawl-down`, `starwars`, `cards`, `fade`, `slides`, `ticker`, `typewriter`.

## Drop risks

- **0.13.1 regression:** shipping the Credits tab UI without the matching admin API fields / write routes.
- Config save wiping `credits.*`.
- Replacing the RAF crawl with CSS animation “because it is simpler”.

## After-change verify

- [ ] `GET /api/admin/credits` returns `cast` plus enable/mode/look.
- [ ] Credits tab loads styles, can pin a job, and can change command permission without a 404.
- [ ] Overlay still scrolls in a transparent Webpage source (document if you only smoke-tested in a normal browser).
- [ ] Status hub shows credits on/off and unique count.
- [ ] Sources list points at the built-in overlay (standalone :3854 stays optional).
