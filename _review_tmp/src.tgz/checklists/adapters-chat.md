# Checklist — Adapters / chat

Home: `fridge-stream-core/adapters/` (`kick.py`, `twitch.py`, `youtube.py`). Overlay: `overlay/chat.html`.

## Must keep

- [ ] Platforms are adapters only. They emit normalized chat / alert events onto the EventBus. They do not own commands, points, or games.
- [ ] Kick, Twitch, and YouTube all default **off** in `config.yaml`, `config.example.yaml`, and `core/config.py` DEFAULTS.
- [ ] Kick: Pusher chat, emotes, badges, chatroom id autodetection persisted to `config.yaml`.
- [ ] Twitch: anonymous IRC listen. No OAuth required to read chat.
- [ ] YouTube: dual-mode `innertube` / `official` / `auto`. Official needs `api_key`; innertube needs `video_id`.
- [ ] Chat overlay at `/overlay/chat.html` (Core :3850). Supports `?platform=` and `?platforms=` filters.
- [ ] Kick emote tokens `[emote:id:name]` resolve to `files.kick.com`.
- [ ] Core broadcasts `type:chat` and `chat_history` on the overlay WebSocket.
- [ ] Enabling a platform in Config still requires a Core **restart** (document that; do not pretend it hot-applies unless you actually made it hot).

## Drop risks

- Adding a fourth platform by stuffing logic into `kick.py` instead of a new adapter.
- Flipping a platform default to `true` in DEFAULTS or example config.
- Chat overlay losing multi-platform filters when the WS payload shape changes.

## After-change verify

- [ ] Example config still has all three platforms `enabled: false`.
- [ ] Admin → Status still lists each adapter separately.
- [ ] Admin → Sources still links `/overlay/chat.html`.
- [ ] Chat overlay still works with no platform query (all enabled platforms) and with a filter.
